﻿ALTER TABLE process_timeline_node DROP COLUMN interval_days;
ALTER TABLE process_timeline_node ADD COLUMN start_time TIMESTAMP NULL;
ALTER TABLE process_timeline_node ADD COLUMN end_time TIMESTAMP NULL;